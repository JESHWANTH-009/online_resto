import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { CheckCircle, Home, ClipboardList } from 'lucide-react';

const OrderConfirmationPage: React.FC = () => {
  const { orderId } = useParams<{ orderId: string }>();
  const [estimatedTime, setEstimatedTime] = useState<string>('');
  
  useEffect(() => {
    // Calculate the estimated pickup time (20-30 minutes from now)
    const now = new Date();
    const pickupTime = new Date(now.getTime() + 25 * 60000); // 25 minutes from now
    
    const hours = pickupTime.getHours();
    const minutes = pickupTime.getMinutes();
    
    const formattedHours = hours % 12 || 12;
    const amPm = hours >= 12 ? 'PM' : 'AM';
    const formattedMinutes = minutes < 10 ? `0${minutes}` : minutes;
    
    setEstimatedTime(`${formattedHours}:${formattedMinutes} ${amPm}`);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-md overflow-hidden">
          <div className="bg-emerald-500 p-6 text-white text-center">
            <CheckCircle className="h-16 w-16 mx-auto mb-4" />
            <h1 className="text-3xl font-bold">Order Confirmed!</h1>
            <p className="text-emerald-100 mt-2">
              Thank you for your order. We're preparing your food now!
            </p>
          </div>
          
          <div className="p-6">
            <div className="mb-6 pb-6 border-b border-gray-200">
              <div className="flex justify-between mb-2">
                <span className="text-gray-600">Order ID:</span>
                <span className="font-semibold">{orderId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Estimated Pickup Time:</span>
                <span className="font-semibold">{estimatedTime}</span>
              </div>
            </div>
            
            <div className="mb-6 bg-amber-50 p-4 rounded-md">
              <h3 className="font-semibold text-amber-800 mb-2">Important Information</h3>
              <ul className="text-amber-700 text-sm space-y-1">
                <li>• Your order will be ready for pickup in approximately 20-30 minutes.</li>
                <li>• Please have your order ID ready when you arrive.</li>
                <li>• Payment will be collected at pickup.</li>
                <li>• For any questions, call us at (555) 123-4567.</li>
              </ul>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/"
                className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-800 py-3 px-4 rounded-md font-medium transition-colors flex items-center justify-center gap-2"
              >
                <Home className="h-4 w-4" />
                Return Home
              </Link>
              <Link
                to="/history"
                className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white py-3 px-4 rounded-md font-medium transition-colors flex items-center justify-center gap-2"
              >
                <ClipboardList className="h-4 w-4" />
                View Order History
              </Link>
            </div>
          </div>
        </div>

        <div className="mt-8 text-center">
          <p className="text-gray-600">
            We appreciate your business! If you have any questions or need assistance, please call us at (555) 123-4567.
          </p>
        </div>
      </div>
    </div>
  );
};

export default OrderConfirmationPage;