import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Search } from 'lucide-react';

interface HistoryOrder {
  id: string;
  date: string;
  items: { name: string; quantity: number }[];
  total: number;
  status: 'pending' | 'ready' | 'completed';
}

// Mock data for demonstration
const mockOrders: HistoryOrder[] = [
  {
    id: 'ORD12345',
    date: 'June 15, 2025 - 12:30 PM',
    items: [
      { name: 'Grilled Salmon', quantity: 1 },
      { name: 'Fresh Lemonade', quantity: 2 }
    ],
    total: 34.97,
    status: 'completed'
  },
  {
    id: 'ORD67890',
    date: 'June 14, 2025 - 6:45 PM',
    items: [
      { name: 'Chicken Parmesan', quantity: 1 },
      { name: 'Tiramisu', quantity: 1 },
      { name: 'Craft Root Beer', quantity: 1 }
    ],
    total: 30.97,
    status: 'completed'
  }
];

const OrderHistoryPage: React.FC = () => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [searchSubmitted, setSearchSubmitted] = useState(false);
  const [orders, setOrders] = useState<HistoryOrder[]>([]);
  const [error, setError] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!phoneNumber.trim()) {
      setError('Please enter a phone number');
      return;
    }
    
    if (!/^\d{10}$/.test(phoneNumber.replace(/\D/g, ''))) {
      setError('Please enter a valid 10-digit phone number');
      return;
    }
    
    setError('');
    setSearchSubmitted(true);
    
    // In a real application, this would be an API call to fetch orders by phone number
    // For now, we'll just use our mock data
    setOrders(mockOrders);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <Link
          to="/"
          className="inline-flex items-center text-indigo-600 hover:text-indigo-800 font-medium mb-6"
        >
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Home
        </Link>

        <h1 className="text-3xl font-bold mb-8">Order History</h1>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-1">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold mb-4">Find Your Orders</h2>
              <p className="text-gray-600 mb-4">
                Enter the phone number you used to place your orders.
              </p>
              
              <form onSubmit={handleSearch}>
                <div className="mb-4">
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className={`w-full px-4 py-2 border rounded-md focus:ring-indigo-500 focus:border-indigo-500 ${
                      error ? 'border-red-500' : 'border-gray-300'
                    }`}
                    placeholder="(555) 123-4567"
                  />
                  {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
                </div>
                <button
                  type="submit"
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2 px-4 rounded-md font-medium transition-colors flex items-center justify-center gap-2"
                >
                  <Search className="h-4 w-4" />
                  Search Orders
                </button>
              </form>
            </div>
          </div>

          <div className="md:col-span-2">
            {!searchSubmitted ? (
              <div className="bg-white rounded-lg shadow-md p-6 text-center">
                <div className="text-gray-500 my-8">
                  <p className="text-lg">Enter your phone number to see your order history.</p>
                </div>
              </div>
            ) : orders.length === 0 ? (
              <div className="bg-white rounded-lg shadow-md p-6 text-center">
                <div className="text-gray-500 my-8">
                  <p className="text-lg">No orders found for this phone number.</p>
                  <p className="mt-2">Please check the number and try again.</p>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-4 border-b border-gray-200">
                  <h2 className="text-lg font-semibold">Your Past Orders</h2>
                </div>

                <div className="divide-y divide-gray-200">
                  {orders.map((order) => (
                    <div key={order.id} className="p-6">
                      <div className="flex flex-col md:flex-row justify-between mb-4">
                        <div>
                          <h3 className="text-lg font-medium">Order #{order.id}</h3>
                          <p className="text-gray-500 text-sm">{order.date}</p>
                        </div>
                        <div className="mt-2 md:mt-0">
                          <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                            order.status === 'completed'
                              ? 'bg-green-100 text-green-800'
                              : order.status === 'ready'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-yellow-100 text-yellow-800'
                          }`}>
                            {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                          </span>
                        </div>
                      </div>

                      <div className="mb-4">
                        <h4 className="text-sm font-medium text-gray-700 mb-2">Items:</h4>
                        <ul className="text-sm text-gray-600">
                          {order.items.map((item, index) => (
                            <li key={index} className="mb-1">
                              {item.quantity}x {item.name}
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="flex justify-between items-center">
                        <div className="text-gray-600">
                          Total: <span className="font-semibold">${order.total.toFixed(2)}</span>
                        </div>
                        <Link
                          to={`/confirmation/${order.id}`}
                          className="text-indigo-600 hover:text-indigo-800 text-sm font-medium"
                        >
                          View Details
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderHistoryPage;