import React from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { getPopularItems } from '../data/menuData';
import MenuCard from '../components/MenuCard';
import { ArrowRight, UtensilsCrossed, Clock, Award } from 'lucide-react';

const HomePage: React.FC = () => {
  const popularItems = getPopularItems();
  const { totalItems } = useCart();

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[70vh] min-h-[500px] bg-cover bg-center flex items-center"
        style={{ backgroundImage: 'url(https://images.pexels.com/photos/1639562/pexels-photo-1639562.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2)' }}>
        <div className="absolute inset-0 bg-black/60"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-2xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 leading-tight">
              Delicious Food, <span className="text-amber-400">Digital Ordering</span>
            </h1>
            <p className="text-xl text-white/90 mb-8">
              Skip the wait and order ahead. Fresh, flavorful meals ready when you are.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                to="/menu"
                className="bg-amber-500 hover:bg-amber-600 text-white px-8 py-3 rounded-full font-medium transition-colors duration-300 text-center"
              >
                View Our Menu
              </Link>
              <Link
                to={totalItems > 0 ? "/cart" : "/menu"}
                className="bg-white hover:bg-gray-100 text-gray-900 px-8 py-3 rounded-full font-medium transition-colors duration-300 text-center"
              >
                {totalItems > 0 ? "View Cart" : "Start Order"}
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose The Digital Diner?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-gray-50 p-6 rounded-lg text-center">
              <div className="inline-flex items-center justify-center h-14 w-14 rounded-full bg-indigo-100 text-indigo-600 mb-4">
                <UtensilsCrossed className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Delicious Menu</h3>
              <p className="text-gray-600">
                Featuring fresh ingredients and chef-crafted recipes that will delight your taste buds.
              </p>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg text-center">
              <div className="inline-flex items-center justify-center h-14 w-14 rounded-full bg-amber-100 text-amber-600 mb-4">
                <Clock className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Quick Pickup</h3>
              <p className="text-gray-600">
                Order ahead and skip the wait. Your food will be ready when you arrive.
              </p>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg text-center">
              <div className="inline-flex items-center justify-center h-14 w-14 rounded-full bg-emerald-100 text-emerald-600 mb-4">
                <Award className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Quality Guaranteed</h3>
              <p className="text-gray-600">
                We stand behind every dish. Satisfaction guaranteed or we'll make it right.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Popular Items Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold">Popular Items</h2>
            <Link to="/menu" className="text-indigo-600 hover:text-indigo-800 flex items-center gap-1 font-medium">
              View full menu <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {popularItems.map((item) => (
              <MenuCard key={item.id} item={item} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-indigo-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Order?</h2>
          <p className="text-indigo-100 max-w-2xl mx-auto mb-8">
            Whether you're craving our famous Chicken Parmesan or a sweet dessert, we've got you covered. Order now for pickup!
          </p>
          <Link
            to="/menu"
            className="inline-block bg-white text-indigo-600 hover:bg-gray-100 px-8 py-3 rounded-full font-medium transition-colors duration-300"
          >
            Browse Our Menu
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;