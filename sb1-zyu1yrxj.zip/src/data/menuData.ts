import { MenuItem, Category } from '../types';

export const categories: Category[] = [
  {
    id: '1',
    name: 'Appetizers',
    image: 'https://images.pexels.com/photos/6941033/pexels-photo-6941033.jpeg?auto=compress&cs=tinysrgb&w=600'
  },
  {
    id: '2',
    name: 'Main Courses',
    image: 'https://images.pexels.com/photos/2098085/pexels-photo-2098085.jpeg?auto=compress&cs=tinysrgb&w=600'
  },
  {
    id: '3',
    name: 'Desserts',
    image: 'https://images.pexels.com/photos/376464/pexels-photo-376464.jpeg?auto=compress&cs=tinysrgb&w=600'
  },
  {
    id: '4',
    name: 'Drinks',
    image: 'https://images.pexels.com/photos/1148215/pexels-photo-1148215.jpeg?auto=compress&cs=tinysrgb&w=600'
  }
];

export const menuItems: MenuItem[] = [
  // Appetizers
  {
    id: 'app1',
    name: 'Crispy Calamari',
    description: 'Lightly battered calamari rings served with our signature spicy aioli',
    price: 12.99,
    image: 'https://images.pexels.com/photos/2338407/pexels-photo-2338407.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'Appetizers',
    popular: true
  },
  {
    id: 'app2',
    name: 'Spinach Artichoke Dip',
    description: 'Creamy blend of spinach, artichokes, and melted cheeses served with tortilla chips',
    price: 10.99,
    image: 'https://images.pexels.com/photos/1211887/pexels-photo-1211887.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'Appetizers'
  },
  {
    id: 'app3',
    name: 'Bruschetta',
    description: 'Toasted baguette topped with fresh tomatoes, basil, and balsamic glaze',
    price: 8.99,
    image: 'https://images.pexels.com/photos/2338407/pexels-photo-2338407.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'Appetizers'
  },
  
  // Main Courses
  {
    id: 'main1',
    name: 'Grilled Salmon',
    description: 'Atlantic salmon served with seasonal vegetables and lemon herb butter',
    price: 24.99,
    image: 'https://images.pexels.com/photos/3655916/pexels-photo-3655916.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'Main Courses',
    popular: true
  },
  {
    id: 'main2',
    name: 'Chicken Parmesan',
    description: 'Breaded chicken breast topped with marinara and mozzarella, served with pasta',
    price: 18.99,
    image: 'https://images.pexels.com/photos/958545/pexels-photo-958545.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'Main Courses',
    popular: true
  },
  {
    id: 'main3',
    name: 'Filet Mignon',
    description: '8oz filet served with garlic mashed potatoes and grilled asparagus',
    price: 32.99,
    image: 'https://images.pexels.com/photos/323682/pexels-photo-323682.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'Main Courses'
  },
  {
    id: 'main4',
    name: 'Vegetable Stir Fry',
    description: 'Fresh seasonal vegetables sautéed in our signature sauce served over rice',
    price: 16.99,
    image: 'https://images.pexels.com/photos/165776/pexels-photo-165776.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'Main Courses'
  },
  
  // Desserts
  {
    id: 'des1',
    name: 'Chocolate Lava Cake',
    description: 'Warm chocolate cake with a molten center, served with vanilla ice cream',
    price: 9.99,
    image: 'https://images.pexels.com/photos/132694/pexels-photo-132694.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'Desserts',
    popular: true
  },
  {
    id: 'des2',
    name: 'New York Cheesecake',
    description: 'Classic creamy cheesecake with a graham cracker crust and berry compote',
    price: 8.99,
    image: 'https://images.pexels.com/photos/1126359/pexels-photo-1126359.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'Desserts'
  },
  {
    id: 'des3',
    name: 'Tiramisu',
    description: 'Italian coffee-flavored dessert with layers of mascarpone cheese and ladyfingers',
    price: 7.99,
    image: 'https://images.pexels.com/photos/6879421/pexels-photo-6879421.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'Desserts'
  },
  
  // Drinks
  {
    id: 'drk1',
    name: 'Fresh Lemonade',
    description: 'House-made lemonade with a hint of mint',
    price: 4.99,
    image: 'https://images.pexels.com/photos/158053/fresh-orange-juice-squeezed-refreshing-citrus-158053.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'Drinks'
  },
  {
    id: 'drk2',
    name: 'Craft Root Beer',
    description: 'Small-batch root beer with notes of vanilla and cinnamon',
    price: 3.99,
    image: 'https://images.pexels.com/photos/2983099/pexels-photo-2983099.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'Drinks'
  },
  {
    id: 'drk3',
    name: 'Raspberry Iced Tea',
    description: 'House-brewed iced tea infused with fresh raspberries',
    price: 4.49,
    image: 'https://images.pexels.com/photos/792613/pexels-photo-792613.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'Drinks'
  }
];

export const getMenuItemsByCategory = (categoryName: string): MenuItem[] => {
  return menuItems.filter(item => item.category === categoryName);
};

export const getPopularItems = (): MenuItem[] => {
  return menuItems.filter(item => item.popular);
};