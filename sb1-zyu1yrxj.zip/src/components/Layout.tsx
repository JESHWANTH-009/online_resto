import React, { useState, useEffect } from 'react';
import { Outlet, useLocation, Link } from 'react-router-dom';
import { Utensils, Menu, X, ShoppingCart } from 'lucide-react';
import { useCart } from '../context/CartContext';

const Layout: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();
  const { totalItems } = useCart();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  return (
    <div className="min-h-screen flex flex-col bg-stone-50">
      <header 
        className={`sticky top-0 z-50 transition-all duration-300 ${
          isScrolled 
            ? 'bg-white shadow-md py-2' 
            : 'bg-gradient-to-b from-black/70 to-transparent py-4'
        }`}
      >
        <div className="container mx-auto px-4 flex justify-between items-center">
          <Link 
            to="/" 
            className="flex items-center gap-2 text-xl font-bold"
          >
            <Utensils 
              className={`h-7 w-7 ${isScrolled ? 'text-amber-600' : 'text-amber-400'}`} 
            />
            <span className={`${isScrolled ? 'text-gray-800' : 'text-white'} transition-colors`}>
              The Digital Diner
            </span>
          </Link>

          {/* Mobile menu button */}
          <div className="flex items-center gap-4">
            <Link 
              to="/cart" 
              className={`relative p-2 rounded-full ${
                isScrolled 
                  ? 'text-gray-800 hover:bg-gray-100' 
                  : 'text-white hover:bg-white/10'
              }`}
            >
              <ShoppingCart className="h-6 w-6" />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 bg-amber-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                  {totalItems}
                </span>
              )}
            </Link>
            <button
              className={`p-2 rounded-md md:hidden ${
                isScrolled 
                  ? 'text-gray-800 hover:bg-gray-100' 
                  : 'text-white hover:bg-white/10'
              }`}
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            <Link 
              to="/" 
              className={`font-medium transition-colors ${
                isScrolled 
                  ? 'text-gray-800 hover:text-amber-600' 
                  : 'text-white hover:text-amber-300'
              } ${location.pathname === '/' ? 'font-semibold' : ''}`}
            >
              Home
            </Link>
            <Link 
              to="/menu" 
              className={`font-medium transition-colors ${
                isScrolled 
                  ? 'text-gray-800 hover:text-amber-600' 
                  : 'text-white hover:text-amber-300'
              } ${location.pathname.includes('/menu') ? 'font-semibold' : ''}`}
            >
              Menu
            </Link>
            <Link 
              to="/history" 
              className={`font-medium transition-colors ${
                isScrolled 
                  ? 'text-gray-800 hover:text-amber-600' 
                  : 'text-white hover:text-amber-300'
              } ${location.pathname === '/history' ? 'font-semibold' : ''}`}
            >
              Order History
            </Link>
            <Link 
              to="/cart" 
              className={`relative flex items-center gap-1 font-medium px-4 py-2 rounded-full transition-colors ${
                isScrolled 
                  ? 'bg-amber-500 text-white hover:bg-amber-600' 
                  : 'bg-amber-500 text-white hover:bg-amber-600'
              }`}
            >
              <ShoppingCart className="h-4 w-4" />
              Cart
              {totalItems > 0 && (
                <span className="ml-1 bg-white text-amber-500 text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                  {totalItems}
                </span>
              )}
            </Link>
          </nav>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden absolute top-full left-0 right-0 bg-white shadow-md py-4 px-6 flex flex-col gap-4 animated fadeIn">
            <Link 
              to="/" 
              className={`font-medium py-2 border-b border-gray-100 ${
                location.pathname === '/' ? 'text-amber-600' : 'text-gray-800'
              }`}
            >
              Home
            </Link>
            <Link 
              to="/menu" 
              className={`font-medium py-2 border-b border-gray-100 ${
                location.pathname.includes('/menu') ? 'text-amber-600' : 'text-gray-800'
              }`}
            >
              Menu
            </Link>
            <Link 
              to="/history" 
              className={`font-medium py-2 ${
                location.pathname === '/history' ? 'text-amber-600' : 'text-gray-800'
              }`}
            >
              Order History
            </Link>
          </div>
        )}
      </header>

      <main className="flex-grow">
        <Outlet />
      </main>

      <footer className="bg-gray-900 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between">
            <div className="mb-6 md:mb-0">
              <div className="flex items-center gap-2 text-xl font-bold mb-4">
                <Utensils className="h-6 w-6 text-amber-400" />
                <span>The Digital Diner</span>
              </div>
              <p className="text-gray-400 max-w-md">
                Serving delicious food with a side of technology. Order online for a seamless dining experience.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-8">
              <div>
                <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
                <ul className="space-y-2">
                  <li><Link to="/" className="text-gray-400 hover:text-amber-400 transition-colors">Home</Link></li>
                  <li><Link to="/menu" className="text-gray-400 hover:text-amber-400 transition-colors">Menu</Link></li>
                  <li><Link to="/cart" className="text-gray-400 hover:text-amber-400 transition-colors">Cart</Link></li>
                  <li><Link to="/history" className="text-gray-400 hover:text-amber-400 transition-colors">Order History</Link></li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4">Contact</h3>
                <address className="not-italic text-gray-400">
                  <p>123 Dining Street</p>
                  <p>Foodville, CA 90210</p>
                  <p className="mt-2">Phone: (555) 123-4567</p>
                  <p>Email: hello@digitaldiner.com</p>
                </address>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} The Digital Diner. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;