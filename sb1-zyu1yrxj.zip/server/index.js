import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import { PrismaClient } from '@prisma/client';

// Initialize environment variables
dotenv.config();

const app = express();
const prisma = new PrismaClient();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB Connection
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/digital-diner')
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('MongoDB connection error:', err));

// MongoDB Schema for Menu Items
const menuItemSchema = new mongoose.Schema({
  name: String,
  description: String,
  price: Number,
  image: String,
  category: String,
  popular: Boolean
});

const MenuItem = mongoose.model('MenuItem', menuItemSchema);

// Routes
app.get('/api/menu', async (req, res) => {
  try {
    const menuItems = await MenuItem.find();
    res.json(menuItems);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching menu items' });
  }
});

app.get('/api/menu/category/:category', async (req, res) => {
  try {
    const menuItems = await MenuItem.find({ category: req.params.category });
    res.json(menuItems);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching menu items by category' });
  }
});

app.post('/api/orders', async (req, res) => {
  try {
    const { customerName, customerPhone, items, total } = req.body;
    
    const order = await prisma.order.create({
      data: {
        customerName,
        customerPhone,
        items: JSON.stringify(items),
        total,
        status: 'pending',
        estimatedPickupTime: new Date(Date.now() + 30 * 60000) // 30 minutes from now
      }
    });
    
    res.json(order);
  } catch (error) {
    console.error('Order creation error:', error);
    res.status(500).json({ error: 'Error creating order' });
  }
});

app.get('/api/orders/:phone', async (req, res) => {
  try {
    const orders = await prisma.order.findMany({
      where: {
        customerPhone: req.params.phone
      },
      orderBy: {
        createdAt: 'desc'
      }
    });
    
    res.json(orders);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching orders' });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  await prisma.$disconnect();
  process.exit(0);
});